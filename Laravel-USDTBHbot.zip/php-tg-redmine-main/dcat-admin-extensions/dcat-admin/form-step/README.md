<div align="center">
    <img src="http://www.dcatadmin.com/assets/img/logo-text.png" height="80"> 
</div>
<br>


## Dcat Admin 分步表单扩展

### 安装

[扩展安装](http://www.dcatadmin.com/docs/2.x/extension-f.html)

### 使用
 [分步表单](http://www.dcatadmin.com/docs/2.x/model-form-step.html)

