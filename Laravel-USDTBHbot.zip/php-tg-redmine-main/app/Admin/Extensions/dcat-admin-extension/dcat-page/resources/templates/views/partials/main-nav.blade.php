<li class=""><a href="{!! \DcatPage\url('/docs') !!}">Documentation</a></li>

{{-- 多级菜单示例 --}}
{{--<li class="dropdown">--}}
    {{--<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">Menu  <span class="caret"></span></a>--}}
    {{--<ul class="dropdown-menu" role="menu">--}}

        {{--<li><a >Text 1</a></li>--}}
        {{--<li><a >Text 2</a></li>--}}

        {{--<li class="divider"></li>--}}

        {{--<li><a >Text 3</a></li>--}}
        {{--<li><a >Text 4</a></li>--}}
        {{--<li><a >Text 5</a></li>--}}
        {{--<li><a >Text 6</a></li>--}}
        {{--<li><a >Text 7</a></li>--}}
        {{--<li><a >Text 8</a></li>--}}

    {{--</ul>--}}
{{--</li>--}}
