<?php

// Register the extension.
Dcat\Admin\Admin::extend(Dcat\Admin\Extension\Gank\Gank::class);
