<?php 
return [
    'labels' => [
        'TgUser' => 'TgUser',
        'tg-user' => 'TgUser',
    ],
    'fields' => [
        'username' => '用户名',
        'first_name' => '姓',
        'tg_id' => 'tgId',
        'balance' => '余额',
        'status' => '状态',
        'invite_user' => '邀请人',
    ],
    'options' => [
    ],
];
