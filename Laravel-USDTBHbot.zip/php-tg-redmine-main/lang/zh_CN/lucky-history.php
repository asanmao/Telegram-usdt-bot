<?php
return [
    'labels' => [
        'LuckyHistory' => '红包领取记录',
        'lucky-history' => '红包领取记录',
    ],
    'fields' => [
        'user_id' => '领取用户id',
        'lucky_id' => '红包id',
        'is_thunder' => '是否中雷',
        'amount' => '领取金额',
        'lose_money' => '损失金额',
        'first_name' => '用户名',
    ],
    'options' => [
    ],
];
