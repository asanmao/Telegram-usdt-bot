<?php
return [
    'labels' => [
        'LuckyMoney' => '红包',
        'lucky-money' => '红包',
    ],
    'fields' => [
        'sender_id' => '发送用户id',
        'amount' => '红包金额',
        'received' => '被领取金额',
        'number' => '红包个数',
        'lucky' => '是否随机',
        'thunder' => '雷',
        'chat_id' => '群组id',
        'red_list' => '红包数组',
        'sender_name' => '发送者名称',
        'lose_rate' => '红包倍数',
        'status' => '状态',
    ],
    'options' => [
    ],
];
