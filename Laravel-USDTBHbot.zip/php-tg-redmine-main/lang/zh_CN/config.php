<?php 
return [
    'labels' => [
        'Config' => 'Config',
        'config' => 'Config',
    ],
    'fields' => [
        'name' => '配置key',
        'value' => '配置值',
        'group_id' => '群组id',
        'admin_id' => '管理员id',
        'remark' => '描述',
    ],
    'options' => [
    ],
];
