<?php
return [
    'labels' => [
        'AuthGroup' => 'AuthGroup',
        'auth-group' => 'AuthGroup',
    ],
    'fields' => [
        'group_id' => '群组id',
        'remark' => '备注',
        'status' => '状态',
        'service_url' => '客服链接',
        'recharge_url' => '充值链接',
        'channel_url' => '频道链接',
    ],
    'options' => [
    ],
];
