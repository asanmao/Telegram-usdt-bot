<?php

return [

   'lucky_num'=>6,
   'lose_rate'=>1.8,
   'valid_time'=>60,
   'default_balance'=>0,

];
